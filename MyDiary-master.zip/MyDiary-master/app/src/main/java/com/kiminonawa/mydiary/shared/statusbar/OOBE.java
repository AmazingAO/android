package com.kiminonawa.mydiary.shared.statusbar;

/**
 * Created by daxia on 2017/3/28.
 */

public interface OOBE {

    /**
     * Single shot id
     */
    int MAIN_PAGE = 1;
    int MAIN_SETTING = 2;
}
