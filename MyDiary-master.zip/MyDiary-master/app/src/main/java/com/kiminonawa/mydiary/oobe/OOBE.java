package com.kiminonawa.mydiary.oobe;

/**
 * Created by daxia on 2017/3/29.
 */

public interface OOBE {

    int MAIN_PAGE = 0;
}
