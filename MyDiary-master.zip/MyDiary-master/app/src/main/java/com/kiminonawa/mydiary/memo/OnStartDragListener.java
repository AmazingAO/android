package com.kiminonawa.mydiary.memo;

import android.support.v7.widget.RecyclerView;

/**
 * Created by daxia on 2017/1/6.
 */

public interface OnStartDragListener {

    void onStartDrag(RecyclerView.ViewHolder viewHolder);
}
