package com.kiminonawa.mydiary.shared;

/**
 * Created by daxia on 2016/11/7.
 */

public interface EditMode {
    boolean isEditMode();
    void setEditMode(boolean editMode);
}
