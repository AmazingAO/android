#Privacy Policy

In "MyDiary" , all data only save in local in current version , I can't and don't get any text or photo from your devices.

#隱私權政策

在"MyDiary"中，現行的版本所有資料只會儲存在本地端，我不能也不會取得你的任何文字和圖片資料。
